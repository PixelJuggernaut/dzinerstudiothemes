<?php
// Version: 2.0; Themes

global $scripturl;

$txt['show_date_time'] = 'Show Date/Time in header';
$txt['toplink_but1'] = 'Toplink 1 -> Button Name';
$txt['toplink_url1'] = 'Toplink 1 -> Button Url';
$txt['toplink_but2'] = 'Toplink 2 -> Button Name';
$txt['toplink_url2'] = 'Toplink 2 -> Button Url';
$txt['toplink_but3'] = 'Toplink 3 -> Button Name';
$txt['toplink_url3'] = 'Toplink 3 -> Button Url';
$txt['show_rss_icon'] = 'Show RSS icon in header';
$txt['toplinks_desc'] = 'Above Toplinks will be displayed in header';

$txt['login_desc'] = 'Member Login.';
$txt['signup_desc'] = 'Create an Account.';
$txt['forum_search'] = 'Search...';
$txt['pm'] = 'PM:';
$txt['maintenance'] = '(Maintenance)';
$txt['approval_member'] = 'Approval';
$txt['open_reports'] = 'Reports';
$txt['approve'] = 'Approve';
$txt['show_unread'] = 'Unread';
$txt['show_replies'] = 'Replies';
$txt['member_greeting'] = 'Hello';

?>