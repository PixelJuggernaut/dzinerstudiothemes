<?php
// Version: 2.0; Themes

global $scripturl;

$txt['pm'] = 'PM';
$txt['maintenance'] = 'Maintenance';
$txt['approve'] = 'Approve';
$txt['unread'] = 'Unread';
$txt['you_are_here'] = 'You are here:';

?>