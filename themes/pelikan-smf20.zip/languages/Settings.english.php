<?php
// Version: 2.0; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Pelikan is a stylish, trendy and mostly CSS3 based theme.<br /><br />Designed by <a href="http://www.dzinerstudio.com">DzinerStudio</a>';

?>