<?php
// Version: 2.0; Themes

global $scripturl;

$txt['messages_total'] = 'Total Messages: ';
$txt['messages_new'] = 'New';
$txt['maintenance'] = '(Maintenance)';
$txt['approval_member'] = 'Approval';
$txt['open_reports'] = 'Reports';
$txt['forgot_pass'] = 'Forgot your password?';
$txt['create_account'] = 'Register an Account!';

?>