<?php
// Version: 2.0; Themes

global $scripturl;

$txt['show_date_time'] = 'Show Date/Time in header';
$txt['toplink_but1'] = 'Toplink 1 -> Button Name';
$txt['toplink_url1'] = 'Toplink 1 -> Button Url';
$txt['toplink_but2'] = 'Toplink 2 -> Button Name';
$txt['toplink_url2'] = 'Toplink 2 -> Button Url';
$txt['toplink_but3'] = 'Toplink 3 -> Button Name';
$txt['toplink_url3'] = 'Toplink 3 -> Button Url';
$txt['toplinks_desc'] = 'Above Toplinks will be displayed in header';
$txt['facebook_url'] = 'Facebook URL';
$txt['twitter_url'] = 'Twitter URL';
$txt['rss_url'] = 'RSS URL';

$txt['show_unread'] = 'Unread';
$txt['show_replies'] = 'Replies';
$txt['member_greeting'] = 'Hi';

?>