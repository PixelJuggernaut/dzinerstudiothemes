<?php
// Version: 2.0; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'HORIZON Theme by <a href="http://www.dzinerstudio.com">DZINERSTUDIO</a>';

?>