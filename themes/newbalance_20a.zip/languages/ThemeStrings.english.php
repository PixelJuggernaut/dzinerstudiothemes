<?php
// Version: 2.0; Themes

global $scripturl;

$txt['show_date_time'] = 'Show Date/Time in header';
$txt['quicknav_but1'] = 'Quick Link1 -> Button Name';
$txt['quicknav_url1'] = 'Quick Link1 -> Button Url';
$txt['quicknav_but2'] = 'Quick Link2 -> Button Name';
$txt['quicknav_url2'] = 'Quick Link2 -> Button Url';
$txt['quicknav_but3'] = 'Quick Link3 -> Button Name';
$txt['quicknav_url3'] = 'Quick Link3 -> Button Url';
$txt['quicknavs_desc'] = 'Above links will be displayed in header';
$txt['facebook_url'] = 'Facebook URL';
$txt['twitter_url'] = 'Twitter URL';
$txt['rss_url'] = 'RSS URL';

$txt['pm'] = 'PM:';
$txt['new'] = 'new';
$txt['show_unread'] = 'Unread';
$txt['show_replies'] = 'Replies';
$txt['maintenance'] = 'Maintenance!';
$txt['approval_member'] = 'Member Approvals';
$txt['open_reports'] = 'Open Reports';
$txt['forum_search'] = 'Search...';

?>