<?php
// Version: 2.0; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'A clean and modern design coming in four bright colors.<br /><br /><b>Noize</b> by <a href="http://www.dzinerstudio.com"><b>DzinerStudio</b></a>';

?>