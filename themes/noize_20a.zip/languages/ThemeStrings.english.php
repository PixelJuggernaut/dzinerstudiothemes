<?php
// Version: 2.0; Themes

global $scripturl;

$txt['maintenance'] = 'Maintenance';
$txt['approve'] = 'Approve';
$txt['view_unread'] = 'View Unread';
$txt['view_replies'] = 'Replies';
$txt['view_own_posts'] = 'Own Posts';
$txt['forum_search'] = 'Search keywords...';
$txt['choose_color_style'] = 'Choose the color style of Noize theme.';

?>