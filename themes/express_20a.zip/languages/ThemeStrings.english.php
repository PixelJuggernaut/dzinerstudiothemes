<?php
// Version: 2.0; Themes

global $scripturl;

$txt['toplink_but1'] = 'Toplink 1 - Button Name';
$txt['toplink_url1'] = 'Toplink 1 - Button URL';
$txt['toplink_but2'] = 'Toplink 2 - Button Name';
$txt['toplink_url2'] = 'Toplink 2 - Button URL';
$txt['toplink_but3'] = 'Toplink 3 - Button Name';
$txt['toplink_url3'] = 'Toplink 3 - Button URL';
$txt['toplinks_desc'] = '(Above toplinks will be displayed on top of the header.)';

$txt['pm_unread'] = 'Unread';
$txt['messages_total'] = 'Total Messages: ';
$txt['messages_new'] = 'New';
$txt['maintenance'] = '(Maintenance)';
$txt['approval_member'] = 'Approval';
$txt['open_reports'] = 'Reports';
$txt['view_unread'] = 'Show Unread';
$txt['view_replies'] = 'Show Replies';
$txt['view_own_posts'] = 'Own Posts';
$txt['forum_search'] = 'Search keywords...';

?>