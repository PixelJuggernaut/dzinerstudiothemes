<?php
// Version: 2.0; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Expo is a stylish and open design combining light and dark elements with colorful touches. <br /><br />Expo by <a href="http://www.dzinerstudio.com">DzinerStudio</a>';

?>