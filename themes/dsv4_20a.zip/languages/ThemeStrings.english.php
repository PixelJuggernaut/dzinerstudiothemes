<?php
// Version: 2.0; Themes

global $scripturl;

$txt['show_date_time'] = 'Show Date and Time on header?';
$txt['toplink_but1'] = 'Toplink 1 -> Button Name';
$txt['toplink_url1'] = 'Toplink 1 -> Button Url';
$txt['toplink_but2'] = 'Toplink 2 -> Button Name';
$txt['toplink_url2'] = 'Toplink 2 -> Button Url';
$txt['toplink_but3'] = 'Toplink 3 -> Button Name';
$txt['toplink_url3'] = 'Toplink 3 -> Button Url';
$txt['toplinks_desc'] = 'Above toplinks will be displayed on top of the header.';
$txt['show_search'] = 'Show Searchbox on header?';
$txt['change_menustyle'] = 'Change Main Menu Style?';
$txt['menustyle_desc'] = 'If enabled, Custom Dropdown Menu will be replaced with Default SMF Menu.';

$txt['pm_unread'] = 'Unread';
$txt['messages'] = 'Messages: ';
$txt['total_msg'] = 'Total: ';
$txt['maintenance'] = 'Maintenance';
$txt['approve'] = 'Approve';
$txt['view_unread'] = 'View Unread';
$txt['view_replies'] = 'Replies';
$txt['view_own_posts'] = 'Own Posts';
$txt['forum_search'] = 'Search this site...';
$txt['missed_act_mail'] = 'Missed activation email?';
$txt['forgot_pass'] = 'Forgot Password?';
$txt['create_account'] = 'Create Account';

$txt['you_are_here'] = 'You are here:';
?>