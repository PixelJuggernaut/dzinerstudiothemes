	window.addEvent('domready', function(){
		var myMenu = new ImageMenu($$('#kwick .kwick'),{openWidth:180});
	});