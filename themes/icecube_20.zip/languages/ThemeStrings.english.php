<?php
// Version: 2.0; Themes

global $scripturl;

$txt['toplink_but1'] = 'Toplink 1 -> Button Name';
$txt['toplink_url1'] = 'Toplink 1 -> Button Url';
$txt['toplink_but2'] = 'Toplink 2 -> Button Name';
$txt['toplink_url2'] = 'Toplink 2 -> Button Url';
$txt['toplink_but3'] = 'Toplink 3 -> Button Name';
$txt['toplink_url3'] = 'Toplink 3 -> Button Url';
$txt['toplinks_desc'] = 'Above toplinks will be displayed on top of the header.';

$txt['pm'] = 'PM';
$txt['maintenance'] = 'Maintenance';
$txt['approval_member'] = 'Approval';
$txt['unread'] = 'Unread';
$txt['guest_welcome'] ='Welcome, <strong>Guest</strong>.';
?>